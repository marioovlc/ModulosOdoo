{
    'name': 'Empresa de Repartidors',
    'version': '1.0',
    'author': 'Mario',
    'category': 'Uncategorized',
    'summary': 'Gestió d\'una empresa de repartidors',
    'description': 'Mòdul per gestionar una empresa de repartidors',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/repartidor_views.xml',
        'views/vehicle_views.xml',
        'views/client_views.xml',
        'views/repartiment_views.xml',
        'views/menu_views.xml',
        'data/repartiment_data.xml'
    ],
    'installable': True,
    'application': True,
}
