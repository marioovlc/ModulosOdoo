# -*- coding: utf-8 -*-
from . import liga_equipo
from . import liga_partido

# Aqui indicamos que se cargara el fichero "liga_equipo.py" y "liga_partido.py"
# Si creamos mas modelos, deben importarse en este fichero