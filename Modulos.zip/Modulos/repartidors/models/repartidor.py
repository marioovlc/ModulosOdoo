from odoo import models, fields

class Repartidor(models.Model):
    _name = 'repartidor'
    _description = 'Repartidor'

    name = fields.Char(string='Nom', required=True)
    cognoms = fields.Char(string='Cognoms', required=True)
    dni = fields.Char(string='DNI', required=True)
    telefon = fields.Char(string='Telèfon')
    carnet_ciclomotor = fields.Boolean(string='Té carnet de ciclomotor')
    carnet_furgoneta = fields.Boolean(string='Té carnet de furgoneta')
    foto = fields.Binary(string='Foto')
