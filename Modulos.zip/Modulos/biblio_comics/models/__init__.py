# biblio_comics/models/__init__.py
from . import socios
from . import biblioteca_comic
from . import ejemplar_prestamo
