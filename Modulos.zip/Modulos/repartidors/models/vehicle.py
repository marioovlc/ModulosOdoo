from odoo import models, fields

class Vehicle(models.Model):
    _name = 'vehicle'
    _description = 'Vehicle'

    tipus = fields.Selection([('bicicleta', 'Bicicleta'), ('ciclomotor', 'Ciclomotor'), ('furgoneta', 'Furgoneta')], string='Tipus', required=True)
    matricula = fields.Char(string='Matrícula')
    foto = fields.Binary(string='Foto')
    descripcio = fields.Text(string='Descripció')
