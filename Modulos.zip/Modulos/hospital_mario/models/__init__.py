# -*- coding: utf-8 -*-

# hospital/models/__init__.py
from . import pacientes
from . import medicos
from . import diagnostico

