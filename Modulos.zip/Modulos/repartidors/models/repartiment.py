from odoo import models, fields, _
class Repartiment(models.Model):
    _name = 'repartiment'
    _description = 'Repartiment'

    codi = fields.Char(string='Codi', required=True, copy=False, readonly=True, default=lambda self: _('New'))
    data_inici = fields.Datetime(string='Data Inici', required=True)
    data_retorn = fields.Datetime(string='Data Retorn')
    data_recepcio = fields.Datetime(string='Data Recepció', required=True)
    repartidor_id = fields.Many2one('repartidor', string='Repartidor', required=True)
    vehicle_id = fields.Many2one('vehicle', string='Vehicle', required=True)
    km_repartiment = fields.Float(string='Kilòmetres')
    pes_paquet = fields.Float(string='Pes (kg)')
    volum_paquet = fields.Float(string='Volum')
    observacions = fields.Text(string='Observacions')
    estat_entrega = fields.Selection([('no_ha_eixit', 'No ha eixit'), ('de_cami', 'De camí'), ('entregada', 'Entregada')], string='Estat', required=True)
    client_emissor_id = fields.Many2one('client', string='Client Emissor', required=True)
    client_receptor_id = fields.Many2one('client', string='Client Receptor', required=True)
