from odoo import models, fields

class Client(models.Model):
    _name = 'client'
    _description = 'Client'

    name = fields.Char(string='Nom', required=True)
    cognoms = fields.Char(string='Cognoms', required=True)
    dni = fields.Char(string='DNI', required=True)
    telefon = fields.Char(string='Telèfon')
