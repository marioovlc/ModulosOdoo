# -*- coding: utf-8 -*-
from . import liga_equipo_wizard